#!/bin/sh

file_list=`ls -a | sort`

SAVEIFS=$IFS
IFS=$(echo -en "\n\b")

for file_a in $file_list;
do
   for file_b in $file_list;
   do
	if [ $file_a = $file_b ]
	then
		continue
	fi
	echo "Processing:"${file_a}" & "${file_b};
   done
done

IFS=$SAVEIFS
